<footer>
    <div class="container-fluid text-center">
        <p class="lead">&copy; <?php echo date('Y') ?></p>
    </div>
</footer>
<script>
    $(".dataTable").DataTable();
</script>
</body>
</html>
